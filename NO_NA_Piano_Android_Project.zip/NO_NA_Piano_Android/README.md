# NO NA Piano — Android project (prototype)

Ini adalah proyek Android Studio yang membungkus prototipe HTML NO NA Piano ke dalam aplikasi Android berbasis WebView.

## Build APK
1. Instal Android Studio versi stabil dan Android SDK Platform 35.
2. Ekstrak ZIP ini.
3. Buka folder `NO_NA_Piano` dari Android Studio.
4. Tunggu Gradle Sync selesai. Jika diminta, instal komponen SDK yang disarankan.
5. Untuk mencoba di HP, aktifkan Developer options + USB debugging, sambungkan HP, lalu tekan Run.
6. Untuk membuat APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Yang tersedia
- Nama aplikasi: NO NA Piano
- Orientasi potret
- Prototipe HTML berjalan offline di WebView
- JavaScript dan penyimpanan lokal aktif
- Pemilih file audio tersedia untuk memilih audio lokal

## Catatan penting
- Ini source project, bukan APK yang sudah dikompilasi.
- Lagu-lagu dalam prototipe memakai pola ubin/nada demo; rekaman asli NO NA tidak disertakan.
- Untuk merilis atau membagikan game, gunakan audio dan aset yang hak penggunaannya kamu miliki.
- Untuk membuat game ritme yang benar-benar mengikuti lagu, perlu chart/timing khusus per track.
